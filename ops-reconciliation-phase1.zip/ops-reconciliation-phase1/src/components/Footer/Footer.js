import styles from './Footer.module.css'

export default function Footer() {
    return (
        <div className={styles.footer}><span className={styles.span}>© Shanghai Pudong Development Bank</span></div>
    )
}
